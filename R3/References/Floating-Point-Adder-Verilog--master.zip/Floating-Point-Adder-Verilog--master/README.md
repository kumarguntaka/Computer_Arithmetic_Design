# Half Precision Floating Point Representation In Verilog
the file name fadd.v is a half precision FPR adder IEEE 754 Standard 
Sign Bit 1
Exponant Bit 5
Mantisa Bit 10
th MUX is 16:4
the file barrel shift resistor is of 16 bit
the adder used is Ripple Carry Adder

# more need to be adder ...
