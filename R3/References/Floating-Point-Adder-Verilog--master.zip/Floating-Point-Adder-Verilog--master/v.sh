clear
# iverilog cla.v
# iverilog mux.v
# iverilog barrel.v
# iverilog rca.v
iverilog fadd.v
iverilog testbench.v
./a.out
rm a.out