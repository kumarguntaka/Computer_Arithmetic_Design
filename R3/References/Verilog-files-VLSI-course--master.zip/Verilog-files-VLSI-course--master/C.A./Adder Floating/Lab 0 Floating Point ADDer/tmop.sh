iverilog tobeoperatedupon.v tobeoperatedon_tb.v -o pal1
