EXECUTE
 iverilog main4.v tbmain2.v -o min4a //for decimal output
 iverilog main4.v tbmain3.v -o min4a //for binary output
