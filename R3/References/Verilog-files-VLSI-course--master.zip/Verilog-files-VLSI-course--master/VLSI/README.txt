1 . Recursion doubling
2 . Wallace multiplier 8 bit
3 . Testbenchgenerator for verilog (python)
